import { IsNotEmpty, IsEmail, Length } from 'class-validator';

export class CreateOrUpdateUserDto {
  @IsNotEmpty()
  @Length(1, 50)
  username: string;

  @IsNotEmpty()
  @IsEmail()
  @Length(1, 255)
  email: string;
}
