import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import { IsNotEmpty, IsEmail, Length } from 'class-validator';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  @IsNotEmpty()
  @Length(1, 50)
  username: string;

  @Column()
  @IsNotEmpty()
  @IsEmail()
  @Length(1, 255)
  email: string;
}
