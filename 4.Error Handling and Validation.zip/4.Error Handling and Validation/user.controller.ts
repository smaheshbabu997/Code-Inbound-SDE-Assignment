import { Controller, Get, Post, Put, Delete, Body, Param, HttpException, HttpStatus } from '@nestjs/common';
import { UserService } from './user.service';
import { User } from './user.entity';
import { CreateOrUpdateUserDto } from './dto/user.dto'; // Define DTO for input validation

@Controller('users')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get()
  async findAll(): Promise<User[]> {
    try {
      return await this.userService.findAll();
    } catch (error) {
      throw new HttpException('Internal Server Error', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<User> {
    try {
      return await this.userService.findOne(parseInt(id, 10));
    } catch (error) {
      throw new HttpException(error.message || 'User not found', HttpStatus.NOT_FOUND);
    }
  }

  @Post()
  async create(@Body() createUserDto: CreateOrUpdateUserDto): Promise<User> {
    try {
      const user = await this.userService.create(createUserDto);
      return user;
    } catch (error) {
      throw new HttpException(error.message || 'Invalid input', HttpStatus.BAD_REQUEST);
    }
  }

  @Put(':id')
  async update(@Param('id') id: string, @Body() updateUserDto: CreateOrUpdateUserDto): Promise<User> {
    try {
      return await this.userService.update(parseInt(id, 10), updateUserDto);
    } catch (error) {
      throw new HttpException(error.message || 'Invalid input', HttpStatus.BAD_REQUEST);
    }
  }

  @Delete(':id')
  async remove(@Param('id') id: string): Promise<void> {
    try {
      await this.userService.remove(parseInt(id, 10));
    } catch (error) {
      throw new HttpException(error.message || 'User not found', HttpStatus.NOT_FOUND);
    }
  }
}
