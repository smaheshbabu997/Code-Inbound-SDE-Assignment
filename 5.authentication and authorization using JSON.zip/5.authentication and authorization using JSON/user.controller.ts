import { Controller, Get, Post, Put, Delete, Body, Param, UseGuards } from '@nestjs/common';
import { UserService } from './user.service';
import { User } from './user.entity';
import { CreateOrUpdateUserDto } from './dto/user.dto';
import { JwtAuthGuard } from './jwt-auth.guard'; // Create this guard

@Controller('users')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @UseGuards(JwtAuthGuard) // Apply the guard to this route
  @Get()
  async findAll(): Promise<User[]> {
    return this.userService.findAll();
  }

  // ... other routes ...

}
